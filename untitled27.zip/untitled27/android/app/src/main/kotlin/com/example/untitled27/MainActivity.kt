package com.example.untitled27

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

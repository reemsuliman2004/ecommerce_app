import 'package:dio/dio.dart';

import '../model/category model.dart';
import '../token_storage.dart';

class CategoryController {
  final Dio _dio = Dio();
  final String baseUrl = "${ApiConfig.baseUrl}/category";

  Future<List<CategoryModel>> getCategoriesByWarehouse(int warehouseId) async {
    try {
      final token = globalToken;
      if (token == null || token.isEmpty) {
        print("❌ لا يوجد توكين");
        return [];
      }

      final response = await _dio.get(
        "$baseUrl?warehouse_id=$warehouseId",
        options: Options(
          headers: {
            'Authorization': 'Bearer $token',
            'Accept': 'application/json',
          },
        ),
      );

      final data = response.data is List
          ? response.data
          : response.data['data'];

      return (data as List)
          .map((json) => CategoryModel.fromJson(json))
          .toList();
    } catch (e) {
      print("Error fetching categories: $e");
      rethrow;
    }
  }
}



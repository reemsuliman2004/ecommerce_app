import 'package:meta/meta.dart';
import 'dart:convert';

class CategoryModel {
  final int id;
  final String categoryName;
  final dynamic categoryPhoto;
  final DateTime createdAt;
  final DateTime updatedAt;
  final List<Warehouse> warehouses;

  CategoryModel({
    required this.id,
    required this.categoryName,
    required this.categoryPhoto,
    required this.createdAt,
    required this.updatedAt,
    required this.warehouses,
  });

  CategoryModel copyWith({
    int? id,
    String? categoryName,
    dynamic categoryPhoto,
    DateTime? createdAt,
    DateTime? updatedAt,
    List<Warehouse>? warehouses,
  }) =>
      CategoryModel(
        id: id ?? this.id,
        categoryName: categoryName ?? this.categoryName,
        categoryPhoto: categoryPhoto ?? this.categoryPhoto,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        warehouses: warehouses ?? this.warehouses,
      );

  factory CategoryModel.fromRawJson(String str) => CategoryModel.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory CategoryModel.fromJson(Map<String, dynamic> json) => CategoryModel(
    id: json["id"],
    categoryName: json["category_name"],
    categoryPhoto: json["category_photo"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    warehouses: List<Warehouse>.from(json["warehouses"].map((x) => Warehouse.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "category_name": categoryName,
    "category_photo": categoryPhoto,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "warehouses": List<dynamic>.from(warehouses.map((x) => x.toJson())),
  };
}

class Warehouse {
  final int id;
  final String warehouseName;
  final String warehouseLocation;
  final String latitude;
  final String longitude;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Pivot pivot;

  Warehouse({
    required this.id,
    required this.warehouseName,
    required this.warehouseLocation,
    required this.latitude,
    required this.longitude,
    required this.createdAt,
    required this.updatedAt,
    required this.pivot,
  });

  Warehouse copyWith({
    int? id,
    String? warehouseName,
    String? warehouseLocation,
    String? latitude,
    String? longitude,
    DateTime? createdAt,
    DateTime? updatedAt,
    Pivot? pivot,
  }) =>
      Warehouse(
        id: id ?? this.id,
        warehouseName: warehouseName ?? this.warehouseName,
        warehouseLocation: warehouseLocation ?? this.warehouseLocation,
        latitude: latitude ?? this.latitude,
        longitude: longitude ?? this.longitude,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        pivot: pivot ?? this.pivot,
      );

  factory Warehouse.fromRawJson(String str) => Warehouse.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Warehouse.fromJson(Map<String, dynamic> json) => Warehouse(
    id: json["id"],
    warehouseName: json["warehouse_name"],
    warehouseLocation: json["warehouse_location"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    pivot: Pivot.fromJson(json["pivot"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "warehouse_name": warehouseName,
    "warehouse_location": warehouseLocation,
    "latitude": latitude,
    "longitude": longitude,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "pivot": pivot.toJson(),
  };
}

class Pivot {
  final int categoryId;
  final int warehouseId;

  Pivot({
    required this.categoryId,
    required this.warehouseId,
  });

  Pivot copyWith({
    int? categoryId,
    int? warehouseId,
  }) =>
      Pivot(
        categoryId: categoryId ?? this.categoryId,
        warehouseId: warehouseId ?? this.warehouseId,
      );

  factory Pivot.fromRawJson(String str) => Pivot.fromJson(json.decode(str));

  String toRawJson() => json.encode(toJson());

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
    categoryId: json["category_id"],
    warehouseId: json["warehouse_id"],
  );

  Map<String, dynamic> toJson() => {
    "category_id": categoryId,
    "warehouse_id": warehouseId,
  };
}




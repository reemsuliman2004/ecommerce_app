// lib/token_storage.dart

String? globalToken;
// lib/config/api_config.dart

class ApiConfig {
  static const String ip = "192.168.1.105"; // هنا تعدل الـ IP مرة وحدة
  static const String port = "8001";

  static String get baseUrl => "http://$ip:$port/api";
}
